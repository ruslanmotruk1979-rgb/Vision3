package com.visionclicker.click

import com.visionclicker.data.SettingsRepository
import com.visionclicker.model.AppRuntime
import com.visionclicker.model.AppSettings
import com.visionclicker.model.ClickMode
import com.visionclicker.model.Limits
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Логика кликов. Один долгоживущий worker наблюдает за флагом «объект в области».
 * Появление объекта запускает сессию кликов, исчезновение мгновенно отменяет её
 * (collectLatest отменяет предыдущий блок), поэтому очередь кликов не копится
 * и корутины не плодятся на каждое обнаружение.
 *
 * Детектор и кликер независимы: частота анализа не зависит от интервала кликов.
 */
class ClickController(
    private val scope: CoroutineScope,
    private val repo: SettingsRepository,
    private val onFatal: (String) -> Unit
) {
    private val present = MutableStateFlow(false)
    private var worker: Job? = null
    private var failures = 0

    fun start() {
        worker?.cancel()
        worker = scope.launch {
            present.collectLatest { p ->
                if (p) {
                    session()
                } else {
                    AppRuntime.clicking.value = false
                }
            }
        }
    }

    fun setPresent(v: Boolean) {
        present.value = v
    }

    /** Немедленно прекращает всё и отменяет запланированные нажатия. */
    fun stop() {
        worker?.cancel()
        worker = null
        present.value = false
        AppRuntime.clicking.value = false
    }

    private suspend fun session() {
        var done = 0
        try {
            while (present.value) {
                val s = repo.current
                if (!s.clickerEnabled) {
                    AppRuntime.clicking.value = false
                    delay(100)
                    continue
                }
                if (s.maxClicksPerAppearance in 1..done) {
                    AppRuntime.clicking.value = false
                    awaitCancellation()
                }

                AppRuntime.clicking.value = true
                val ok = tapOnce(s)
                if (!present.value) break // объект исчез, пока выполнялся жест

                if (ok) {
                    done++
                    AppRuntime.clickCount.value = AppRuntime.clickCount.value + 1L
                }
                if (s.clickMode == ClickMode.SINGLE && ok) {
                    AppRuntime.clicking.value = false
                    awaitCancellation() // ждём исчезновения объекта; новое нажатие — при новом появлении
                }
                delay(s.clickIntervalMs.coerceIn(Limits.MIN_CLICK_INTERVAL_MS, Limits.MAX_CLICK_INTERVAL_MS).toLong())
            }
        } finally {
            AppRuntime.clicking.value = false
        }
    }

    private suspend fun tapOnce(s: AppSettings): Boolean {
        val svc = AutomationAccessibilityService.instance
        if (svc == null) {
            onFatal("Служба специальных возможностей недоступна — нажатия невозможны")
            return false
        }
        val screen = AppRuntime.screen.value
        val p = s.clickerFor(screen.isLandscape)
        val x = (p.x * screen.width).coerceIn(1f, (screen.width - 1).toFloat())
        val y = (p.y * screen.height).coerceIn(1f, (screen.height - 1).toFloat())

        val ok = svc.tap(x, y, s.tapDurationMs.coerceIn(Limits.MIN_TAP_MS, Limits.MAX_TAP_MS).toLong())
        if (ok) {
            failures = 0
        } else {
            failures++
            if (failures >= 5) onFatal("Системе не удаётся выполнить нажатие (5 неудач подряд)")
        }
        return ok
    }
}
