package com.visionclicker.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import com.visionclicker.model.PxRect
import com.visionclicker.model.ScreenSize
import com.visionclicker.util.ScreenMetrics
import org.opencv.core.CvType
import org.opencv.core.Mat

/**
 * Только захват экрана. Не знает ни о распознавании, ни о кликах.
 *
 * Держит последний кадр открытым, поэтому область можно перечитать, даже если экран
 * не менялся (VirtualDisplay не присылает новых кадров на статичной картинке).
 * Из кадра копируется только выбранная область — полноэкранные буферы не создаются.
 */
class ScreenCaptureManager(private val context: Context) {

    private val lock = Any()
    private var thread: HandlerThread? = null
    private var projection: MediaProjection? = null
    private var callback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var held: Image? = null
    private var scratch = ByteArray(0)

    var size: ScreenSize = ScreenSize(0, 0, 0)
        private set

    @Volatile
    var isRunning: Boolean = false
        private set

    /**
     * @param onStopped вызывается, если проекцию остановил пользователь или система
     *                  (кнопка «Остановить трансляцию», блокировка экрана и т.п.).
     */
    fun start(mp: MediaProjection, onStopped: () -> Unit) {
        synchronized(lock) {
            val t = HandlerThread("VC-capture").also { it.start() }
            thread = t
            val h = Handler(t.looper)
            projection = mp

            val cb = object : MediaProjection.Callback() {
                override fun onStop() {
                    val wasRunning = isRunning
                    synchronized(lock) { releaseInternal(stopProjection = false) }
                    if (wasRunning) onStopped()
                }
            }
            callback = cb
            // Android 14+: колбэк обязан быть зарегистрирован ДО createVirtualDisplay
            mp.registerCallback(cb, h)

            val s = ScreenMetrics.real(context)
            size = s
            val r = ImageReader.newInstance(s.width, s.height, PixelFormat.RGBA_8888, 3)
            reader = r
            display = mp.createVirtualDisplay(
                "VisionClicker",
                s.width, s.height, s.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, h
            )
            isRunning = true
        }
    }

    /** Забирает самый свежий кадр. true — если пришёл новый кадр. */
    fun acquire(): Boolean {
        synchronized(lock) {
            val r = reader ?: return false
            val img = try {
                r.acquireLatestImage()
            } catch (e: Exception) {
                null
            } ?: return false
            try {
                held?.close()
            } catch (_: Exception) {
            }
            held = img
            return true
        }
    }

    fun hasFrame(): Boolean = synchronized(lock) { held != null }

    /** Подстраивает захват под новое разрешение/ориентацию. true — если размер изменился. */
    fun resizeIfNeeded(s: ScreenSize): Boolean {
        synchronized(lock) {
            if (!isRunning) return false
            if (s.width == size.width && s.height == size.height) return false
            try {
                held?.close()
            } catch (_: Exception) {
            }
            held = null
            val nr = ImageReader.newInstance(s.width, s.height, PixelFormat.RGBA_8888, 3)
            display?.resize(s.width, s.height, s.densityDpi)
            display?.surface = nr.surface
            reader?.close()
            reader = nr
            size = s
            return true
        }
    }

    /**
     * Копирует область [rect] (координаты экрана) в [out] как CV_8UC4 (RGBA).
     * Буфер для копии переиспользуется.
     */
    fun copyRegion(rect: PxRect, out: Mat): Boolean {
        synchronized(lock) {
            val img = held ?: return false
            val plane = img.planes[0]
            if (plane.pixelStride != 4) return false
            val buf = plane.buffer
            val rowStride = plane.rowStride

            val x0 = rect.left.coerceIn(0, img.width - 1)
            val y0 = rect.top.coerceIn(0, img.height - 1)
            val x1 = rect.right.coerceIn(x0 + 1, img.width)
            val y1 = rect.bottom.coerceIn(y0 + 1, img.height)
            val w = x1 - x0
            val h = y1 - y0
            val rowBytes = w * 4

            if (scratch.size != rowBytes * h) scratch = ByteArray(rowBytes * h)
            for (row in 0 until h) {
                buf.position((y0 + row) * rowStride + x0 * 4)
                buf.get(scratch, row * rowBytes, rowBytes)
            }
            out.create(h, w, CvType.CV_8UC4)
            out.put(0, 0, scratch)
            return true
        }
    }

    /** Полный кадр как Bitmap (для снимка-шаблона). */
    fun grabFullBitmap(): Bitmap? {
        synchronized(lock) {
            val img = held ?: return null
            val plane = img.planes[0]
            val rowPixels = plane.rowStride / plane.pixelStride
            val buf = plane.buffer
            buf.rewind()
            val bmp = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buf)
            return if (rowPixels != img.width) Bitmap.createBitmap(bmp, 0, 0, img.width, img.height) else bmp
        }
    }

    /** Освобождает все ресурсы захвата и останавливает проекцию. */
    fun release() {
        synchronized(lock) { releaseInternal(stopProjection = true) }
    }

    private fun releaseInternal(stopProjection: Boolean) {
        isRunning = false
        try {
            held?.close()
        } catch (_: Exception) {
        }
        held = null
        try {
            display?.release()
        } catch (_: Exception) {
        }
        display = null
        try {
            reader?.close()
        } catch (_: Exception) {
        }
        reader = null

        val mp = projection
        projection = null
        if (mp != null) {
            callback?.let {
                try {
                    mp.unregisterCallback(it)
                } catch (_: Exception) {
                }
            }
            if (stopProjection) {
                try {
                    mp.stop()
                } catch (_: Exception) {
                }
            }
        }
        callback = null
        thread?.quitSafely()
        thread = null
    }
}
