package com.visionclicker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.visionclicker.AppContainer
import com.visionclicker.click.AutomationAccessibilityService
import com.visionclicker.model.AppRuntime
import com.visionclicker.model.ClickMode
import com.visionclicker.model.Limits
import com.visionclicker.model.NormPoint
import com.visionclicker.model.PerformanceMode
import com.visionclicker.model.PxRect
import com.visionclicker.overlay.FloatingOverlayService
import com.visionclicker.util.PermissionState
import com.visionclicker.util.Permissions
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val FRAME_COLORS: List<Int> = listOf(
    0xFF00E5FF, 0xFF00E676, 0xFFFFEB3B, 0xFFFF5252, 0xFFE040FB, 0xFFFFFFFF
).map { it.toInt() }

// ======================================================================= ОБЛАСТЬ

@Composable
fun RegionScreen(perms: PermissionState, container: AppContainer) {
    val ctx = LocalContext.current
    val repo = container.settings
    val regions = container.regions
    val settings by repo.settings.collectAsState()
    val region by regions.region.collectAsState()
    val screen by AppRuntime.screen.collectAsState()
    val editing by AppRuntime.regionEditing.collectAsState()

    var fx by remember(region) { mutableStateOf(region.left.toString()) }
    var fy by remember(region) { mutableStateOf(region.top.toString()) }
    var fw by remember(region) { mutableStateOf(region.width.toString()) }
    var fh by remember(region) { mutableStateOf(region.height.toString()) }

    fun applyFields() {
        val x = fx.toIntOrNull()
        val y = fy.toIntOrNull()
        val w = fw.toIntOrNull()
        val h = fh.toIntOrNull()
        if (x == null || y == null || w == null || h == null) {
            toast(ctx, "Введите числа")
            return
        }
        regions.set(PxRect(x, y, x + w, y + h))
        regions.commit()
        toast(ctx, "Область сохранена")
    }

    fun ensureOverlay(): Boolean {
        if (!perms.overlay) {
            toastLong(ctx, "Нужно разрешение «Поверх других приложений»")
            Permissions.openOverlaySettings(ctx)
            return false
        }
        FloatingOverlayService.start(ctx)
        return true
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Область наблюдения", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        SectionCard("Режим") {
            SwitchRow(
                title = "Весь экран",
                checked = settings.fullScreen,
                hint = "Анализируется весь кадр: нагрузка выше, ложных срабатываний больше."
            ) { v ->
                repo.update { it.copy(fullScreen = v) }
                if (v) AppRuntime.regionEditing.value = false
            }
        }

        if (!settings.fullScreen) {
            SectionCard("Координаты") {
                HintText(
                    "Экран ${screen.width}×${screen.height} px, " +
                        "${if (screen.isLandscape) "альбомная" else "портретная"} ориентация " +
                        "(область запоминается отдельно для каждой ориентации)."
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField("X", fx, Modifier.weight(1f)) { fx = it }
                    NumField("Y", fy, Modifier.weight(1f)) { fy = it }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField("Ширина", fw, Modifier.weight(1f)) { fw = it }
                    NumField("Высота", fh, Modifier.weight(1f)) { fh = it }
                }
                Button(onClick = { applyFields() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Применить и сохранить")
                }
                OutlinedButton(
                    onClick = {
                        regions.center()
                        regions.commit()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("По центру экрана") }
            }

            SectionCard("Настройка пальцем") {
                HintText(
                    "Рамка появится поверх экрана. Тяните рамку, чтобы переместить, " +
                        "и круглые маркеры по углам — чтобы изменить размер. " +
                        "Можно перейти в нужное приложение и настроить область прямо там " +
                        "(кнопка с пунктирным прямоугольником на плавающей панели)."
                )
                if (!editing) {
                    Button(
                        onClick = { if (ensureOverlay()) AppRuntime.regionEditing.value = true },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Начать редактирование") }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                regions.commit()
                                AppRuntime.regionEditing.value = false
                                toast(ctx, "Область сохранена")
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Подтвердить") }
                        OutlinedButton(
                            onClick = {
                                regions.revert()
                                AppRuntime.regionEditing.value = false
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Отмена") }
                    }
                }
            }
        }

        SectionCard("Рамка") {
            SwitchRow(
                title = "Показывать рамку",
                checked = settings.frameVisible,
                hint = "Скрытие рамки не останавливает наблюдение."
            ) { v -> repo.update { it.copy(frameVisible = v) } }

            Text("Цвет", style = MaterialTheme.typography.bodyLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (c in FRAME_COLORS) {
                    androidx.compose.foundation.layout.Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(c))
                            .border(
                                if (settings.frameColor == c) 3.dp else 1.dp,
                                if (settings.frameColor == c) Color.White else Color(0x55FFFFFF),
                                CircleShape
                            )
                            .clickable { repo.update { it.copy(frameColor = c) } }
                    )
                }
            }
            SliderRow(
                title = "Непрозрачность рамки",
                value = settings.frameAlpha,
                range = 0.1f..1f,
                valueText = "${(settings.frameAlpha * 100).roundToInt()}%"
            ) { v -> repo.update { it.copy(frameAlpha = v) } }
            HintText("Рамка рисуется снаружи области и не искажает анализируемые пиксели.")
        }
    }
}

// ======================================================================= КЛИКЕР

@Composable
fun ClickerScreen(perms: PermissionState, container: AppContainer) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = container.settings
    val settings by repo.settings.collectAsState()
    val screen by AppRuntime.screen.collectAsState()
    val unlocked by AppRuntime.markerUnlocked.collectAsState()

    val pt = settings.clickerFor(screen.isLandscape)
    val cxPx = (pt.x * screen.width).roundToInt()
    val cyPx = (pt.y * screen.height).roundToInt()

    var fx by remember(cxPx) { mutableStateOf(cxPx.toString()) }
    var fy by remember(cyPx) { mutableStateOf(cyPx.toString()) }
    var customInterval by remember(settings.clickIntervalMs) { mutableStateOf(settings.clickIntervalMs.toString()) }
    var maxClicks by remember(settings.maxClicksPerAppearance) {
        mutableStateOf(settings.maxClicksPerAppearance.toString())
    }

    fun setPoint(x: Int, y: Int) {
        val p = NormPoint(
            (x.coerceIn(0, screen.width) / screen.width.toFloat()),
            (y.coerceIn(0, screen.height) / screen.height.toFloat())
        )
        repo.update { it.withClicker(screen.isLandscape, p) }
    }

    fun ensureOverlay(): Boolean {
        if (!perms.overlay) {
            toastLong(ctx, "Нужно разрешение «Поверх других приложений»")
            Permissions.openOverlaySettings(ctx)
            return false
        }
        FloatingOverlayService.start(ctx)
        return true
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Кликер", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        SectionCard("Кликер") {
            SwitchRow(
                title = "Кликер включён",
                checked = settings.clickerEnabled,
                hint = "Включается и выключается независимо от мониторинга: при выключенном кликере объект только распознаётся."
            ) { v -> repo.update { it.copy(clickerEnabled = v) } }
            if (!perms.accessibility) {
                HintText("Служба нажатий не включена — клики невозможны.", VcColors.warn)
                FilledTonalButton(onClick = { Permissions.openAccessibilitySettings(ctx) }) {
                    Text("Включить службу нажатий")
                }
            }
        }

        SectionCard("Режим нажатий") {
            for (m in ClickMode.values()) {
                RadioRow(m.title, m.hint, settings.clickMode == m) {
                    repo.update { it.copy(clickMode = m) }
                }
            }
        }

        SectionCard("Частота") {
            val ms = settings.clickIntervalMs
            SliderRow(
                title = "Интервал между нажатиями",
                value = ms.coerceAtMost(5000).toFloat(),
                range = Limits.MIN_CLICK_INTERVAL_MS.toFloat()..5000f,
                valueText = "$ms мс (≈ ${"%.1f".format(1000f / ms)} кл/с)"
            ) { v ->
                val step = if (v < 1000f) 10 else 50
                val n = ((v / step).roundToInt() * step)
                    .coerceIn(Limits.MIN_CLICK_INTERVAL_MS, Limits.MAX_CLICK_INTERVAL_MS)
                repo.update { it.copy(clickIntervalMs = n) }
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                NumField("Свой интервал, мс", customInterval, Modifier.weight(1f)) { customInterval = it }
                FilledTonalButton(onClick = {
                    val v = customInterval.toIntOrNull()
                    if (v == null) {
                        toast(ctx, "Введите число")
                    } else {
                        val n = v.coerceIn(Limits.MIN_CLICK_INTERVAL_MS, Limits.MAX_CLICK_INTERVAL_MS)
                        repo.update { it.copy(clickIntervalMs = n) }
                        if (n != v) toast(ctx, "Допустимо ${Limits.MIN_CLICK_INTERVAL_MS}–${Limits.MAX_CLICK_INTERVAL_MS} мс")
                    }
                }) { Text("OK") }
            }
            SliderRow(
                title = "Длительность касания",
                value = settings.tapDurationMs.toFloat(),
                range = Limits.MIN_TAP_MS.toFloat()..200f,
                valueText = "${settings.tapDurationMs} мс"
            ) { v -> repo.update { it.copy(tapDurationMs = v.roundToInt()) } }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                NumField("Макс. нажатий за одно появление (0 = без лимита)", maxClicks, Modifier.weight(1f)) {
                    maxClicks = it
                }
                FilledTonalButton(onClick = {
                    val v = maxClicks.toIntOrNull()
                    if (v == null) toast(ctx, "Введите число") else repo.update { it.copy(maxClicksPerAppearance = v) }
                }) { Text("OK") }
            }
            HintText(
                "Ограничения: интервал не меньше ${Limits.MIN_CLICK_INTERVAL_MS} мс (до 20 нажатий в секунду). " +
                    "Следующий клик не отправляется, пока не завершился предыдущий."
            )
        }

        SectionCard("Точка нажатия") {
            HintText("Экран ${screen.width}×${screen.height} px. Маркер не связан с областью наблюдения.")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("X", fx, Modifier.weight(1f)) { fx = it }
                NumField("Y", fy, Modifier.weight(1f)) { fy = it }
            }
            Button(
                onClick = {
                    val x = fx.toIntOrNull()
                    val y = fy.toIntOrNull()
                    if (x == null || y == null) toast(ctx, "Введите числа") else setPoint(x, y)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Применить координаты") }

            SwitchRow(
                title = "Показывать маркер на экране",
                checked = settings.markerVisible
            ) { v ->
                repo.update { it.copy(markerVisible = v) }
                if (v) ensureOverlay()
            }

            if (!unlocked) {
                Button(
                    onClick = { if (ensureOverlay()) AppRuntime.markerUnlocked.value = true },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Двигать маркер пальцем") }
            } else {
                Button(
                    onClick = { AppRuntime.markerUnlocked.value = false },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Закрепить маркер") }
                HintText(
                    "Пока маркер разблокирован, он перехватывает касания. " +
                        "Закрепите его — тогда нажатия кликера проходят сквозь маркер.",
                    VcColors.warn
                )
            }

            OutlinedButton(
                onClick = { setPoint(screen.width / 2, screen.height / 2) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Маркер в центр экрана") }

            OutlinedButton(
                onClick = {
                    if (AutomationAccessibilityService.instance == null) {
                        toastLong(ctx, "Служба нажатий не активна")
                    } else {
                        toastLong(ctx, "Тестовое нажатие через 3 секунды в точке ($cxPx, $cyPx)")
                        scope.launch {
                            delay(3000)
                            val svc = AutomationAccessibilityService.instance
                            if (svc != null) {
                                val ok = svc.tap(cxPx.toFloat(), cyPx.toFloat(), repo.current.tapDurationMs.toLong())
                                toast(ctx, if (ok) "Нажатие выполнено" else "Система отклонила жест")
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Тестовый клик (через 3 с)") }
        }
    }
}

// ======================================================================= НАСТРОЙКИ

@Composable
fun SettingsScreen(perms: PermissionState, container: AppContainer) {
    val ctx = LocalContext.current
    val repo = container.settings
    val settings by repo.settings.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Настройки", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        SectionCard("Разрешения") {
            PermissionRow(
                "Поверх других приложений", perms.overlay,
                "Панель, рамка области, маркер", "Выдать"
            ) { Permissions.openOverlaySettings(ctx) }
            PermissionRow(
                "Служба нажатий (спец. возможности)", perms.accessibility,
                "Выполняет нажатия в точке маркера", "Включить"
            ) { Permissions.openAccessibilitySettings(ctx) }
            PermissionRow(
                "Уведомления", perms.notifications,
                "Постоянное уведомление с кнопкой остановки", "Выдать"
            ) { Permissions.openNotificationSettings(ctx) }
            PermissionRow(
                "Без ограничений батареи", perms.batteryUnrestricted,
                "Рекомендуется для долгой работы в фоне", "Открыть"
            ) { Permissions.openBatterySettings(ctx) }
            HintText(
                "Если пункт «Специальные возможности» недоступен (серый) на Android 13+ при установке APK вручную: " +
                    "Настройки → Приложения → Vision Clicker → ⋮ → «Разрешить ограниченные настройки»."
            )
            OutlinedButton(onClick = { Permissions.openAppDetails(ctx) }, modifier = Modifier.fillMaxWidth()) {
                Text("Открыть сведения о приложении")
            }
        }

        SectionCard("Проверка экрана") {
            SliderRow(
                title = "Период проверки",
                value = settings.checkIntervalMs.toFloat(),
                range = Limits.MIN_CHECK_MS.toFloat()..Limits.MAX_CHECK_MS.toFloat(),
                valueText = "${settings.checkIntervalMs} мс (≈ ${1000 / settings.checkIntervalMs} проверок/с)"
            ) { v -> repo.update { it.copy(checkIntervalMs = (v / 10).roundToInt() * 10) } }
            HintText("Меньше период — быстрее реакция, но выше нагрузка на процессор и батарею.")

            Text("Баланс производительности и точности", style = MaterialTheme.typography.titleSmall)
            for (m in PerformanceMode.values()) {
                RadioRow(m.title, m.hint, settings.performance == m) {
                    repo.update { it.copy(performance = m) }
                }
            }

            SliderRow(
                title = "Подтверждение появления",
                value = settings.confirmFrames.toFloat(),
                range = 1f..5f,
                valueText = "${settings.confirmFrames} кадр.",
                steps = 3
            ) { v -> repo.update { it.copy(confirmFrames = v.roundToInt()) } }
            SliderRow(
                title = "Подтверждение исчезновения",
                value = settings.lossFrames.toFloat(),
                range = 1f..5f,
                valueText = "${settings.lossFrames} кадр.",
                steps = 3
            ) { v -> repo.update { it.copy(lossFrames = v.roundToInt()) } }
            HintText("1 кадр — максимально быстрая реакция. Больше — защита от ложных срабатываний и мигания.")
        }

        SectionCard("Плавающая панель") {
            SwitchRow(
                title = "Показывать панель при запуске",
                checked = settings.autoShowPanel
            ) { v -> repo.update { it.copy(autoShowPanel = v) } }
            SwitchRow(
                title = "Запускать в свёрнутом виде",
                checked = settings.panelCollapsedOnStart,
                hint = "Применится при следующем показе панели."
            ) { v -> repo.update { it.copy(panelCollapsedOnStart = v) } }
            SliderRow(
                title = "Непрозрачность панели",
                value = settings.panelOpacity,
                range = 0.4f..1f,
                valueText = "${(settings.panelOpacity * 100).roundToInt()}%"
            ) { v -> repo.update { it.copy(panelOpacity = v) } }
        }

        SectionCard("Безопасность") {
            EmergencyButton()
            OutlinedButton(onClick = { repo.resetSettings() }, modifier = Modifier.fillMaxWidth()) {
                Text("Сбросить настройки к значениям по умолчанию")
            }
            HintText(
                "Снимки экрана не сохраняются и не отправляются в сеть. Захват экрана работает только пока " +
                    "идёт наблюдение; шаблон и настройки хранятся локально на устройстве."
            )
        }

        SectionCard("Ограничения Android") {
            HintText(
                "• Защищённое содержимое (банки, DRM-видео) система не отдаёт в захват — там объект не будет найден.\n" +
                    "• После каждой остановки Android снова запрашивает согласие на захват экрана.\n" +
                    "• Захват и нажатия зависят от производителя устройства и режимов энергосбережения; " +
                    "реальная задержка = период проверки + анализ + выполнение жеста."
            )
        }
    }
}
