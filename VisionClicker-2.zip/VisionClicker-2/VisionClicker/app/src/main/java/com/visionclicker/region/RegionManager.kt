package com.visionclicker.region

import com.visionclicker.data.SettingsRepository
import com.visionclicker.model.AppRuntime
import com.visionclicker.model.NormRect
import com.visionclicker.model.PxRect
import com.visionclicker.model.RegionHandle
import com.visionclicker.model.ScreenSize
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToInt

/**
 * Управляет областью наблюдения. Рабочая копия [region] меняется «вживую»
 * (мониторинг сразу использует новые границы), а [commit] сохраняет её в настройки.
 * Область хранится отдельно для портретной и ландшафтной ориентации в долях экрана.
 */
class RegionManager(private val repo: SettingsRepository) {

    companion object {
        const val MIN_SIZE = 48
    }

    private val _region = MutableStateFlow(load(AppRuntime.screen.value))
    val region: StateFlow<PxRect> = _region.asStateFlow()

    fun reload() {
        _region.value = load(AppRuntime.screen.value)
    }

    fun onScreenChanged() = reload()

    /** Область, которую реально анализирует мониторинг. */
    fun effective(): PxRect {
        val s = AppRuntime.screen.value
        return if (repo.current.fullScreen) PxRect(0, 0, s.width, s.height) else _region.value
    }

    fun set(r: PxRect) {
        _region.value = clamp(r, AppRuntime.screen.value)
    }

    fun move(dx: Int, dy: Int) {
        val s = AppRuntime.screen.value
        val r = _region.value
        val w = r.width
        val h = r.height
        val l = (r.left + dx).coerceIn(0, maxOf(0, s.width - w))
        val t = (r.top + dy).coerceIn(0, maxOf(0, s.height - h))
        _region.value = PxRect(l, t, l + w, t + h)
    }

    fun resize(handle: RegionHandle, dx: Int, dy: Int) {
        val s = AppRuntime.screen.value
        val r = _region.value
        var l = r.left
        var t = r.top
        var rr = r.right
        var b = r.bottom
        when (handle) {
            RegionHandle.TL -> { l += dx; t += dy }
            RegionHandle.TR -> { rr += dx; t += dy }
            RegionHandle.BL -> { l += dx; b += dy }
            RegionHandle.BR -> { rr += dx; b += dy }
        }
        if (handle == RegionHandle.TL || handle == RegionHandle.BL) {
            l = clampInt(l, 0, rr - MIN_SIZE)
        } else {
            rr = clampInt(rr, l + MIN_SIZE, s.width)
        }
        if (handle == RegionHandle.TL || handle == RegionHandle.TR) {
            t = clampInt(t, 0, b - MIN_SIZE)
        } else {
            b = clampInt(b, t + MIN_SIZE, s.height)
        }
        _region.value = PxRect(l, t, rr, b)
    }

    fun center() {
        val s = AppRuntime.screen.value
        val w = (s.width * 0.6f).roundToInt()
        val h = (s.height * 0.3f).roundToInt()
        val l = (s.width - w) / 2
        val t = (s.height - h) / 2
        _region.value = clamp(PxRect(l, t, l + w, t + h), s)
    }

    /** Сохранить текущую область в настройки (для текущей ориентации). */
    fun commit() {
        val s = AppRuntime.screen.value
        val r = _region.value
        val n = NormRect(
            r.left / s.width.toFloat(),
            r.top / s.height.toFloat(),
            r.right / s.width.toFloat(),
            r.bottom / s.height.toFloat()
        )
        repo.update { it.withRegion(s.isLandscape, n) }
    }

    /** Отменить несохранённые изменения. */
    fun revert() = reload()

    private fun load(s: ScreenSize): PxRect {
        val n = repo.current.regionFor(s.isLandscape)
        return clamp(
            PxRect(
                (n.left * s.width).roundToInt(),
                (n.top * s.height).roundToInt(),
                (n.right * s.width).roundToInt(),
                (n.bottom * s.height).roundToInt()
            ),
            s
        )
    }

    private fun clamp(r: PxRect, s: ScreenSize): PxRect {
        val w = clampInt(r.width, MIN_SIZE, s.width)
        val h = clampInt(r.height, MIN_SIZE, s.height)
        val l = clampInt(r.left, 0, s.width - w)
        val t = clampInt(r.top, 0, s.height - h)
        return PxRect(l, t, l + w, t + h)
    }

    private fun clampInt(v: Int, lo: Int, hi: Int): Int = if (hi < lo) lo else v.coerceIn(lo, hi)
}
