package com.visionclicker.ui

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

private fun clampF(v: Float, lo: Float, hi: Float): Float = if (hi < lo) lo else v.coerceIn(lo, hi)

/** Показывает исходное изображение и рамку обрезки (двигается и меняет размер пальцем). */
@Composable
fun CropEditor(source: Bitmap, onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val image = remember(source) { source.asImageBitmap() }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var rect by remember(source) { mutableStateOf<Rect?>(null) }
    val handlePx = with(density) { 36.dp.toPx() }
    val ratio = source.width.toFloat() / source.height.toFloat()

    BackHandler(onBack = onCancel)

    LaunchedEffect(boxSize) {
        if (rect == null && boxSize.width > 0 && boxSize.height > 0) {
            val w = boxSize.width.toFloat()
            val h = boxSize.height.toFloat()
            rect = Rect(w * 0.3f, h * 0.38f, w * 0.7f, h * 0.62f)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Обрежьте снимок: оставьте только нужный объект", style = MaterialTheme.typography.titleMedium)
        HintText(
            "Тяните углы рамки — размер, саму рамку — положение. " +
                "Чем плотнее рамка вокруг объекта, тем надёжнее распознавание."
        )

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .aspectRatio(ratio)
                    .onSizeChanged { boxSize = it }
                    .pointerInput(source) {
                        var mode = 0 // 0 — ничего, 1 — перемещение, 2..5 — углы TL, TR, BL, BR
                        detectDragGestures(
                            onDragStart = { o ->
                                val r = rect
                                mode = if (r == null) {
                                    0
                                } else {
                                    when {
                                        (o - r.topLeft).getDistance() < handlePx -> 2
                                        (o - r.topRight).getDistance() < handlePx -> 3
                                        (o - r.bottomLeft).getDistance() < handlePx -> 4
                                        (o - r.bottomRight).getDistance() < handlePx -> 5
                                        r.contains(o) -> 1
                                        else -> 0
                                    }
                                }
                            },
                            onDrag = { change, drag ->
                                val r = rect
                                if (r != null && mode != 0) {
                                    change.consume()
                                    val w = boxSize.width.toFloat()
                                    val h = boxSize.height.toFloat()
                                    val min = handlePx
                                    var l = r.left
                                    var t = r.top
                                    var rr = r.right
                                    var b = r.bottom
                                    when (mode) {
                                        1 -> {
                                            val dx = clampF(drag.x, -l, w - rr)
                                            val dy = clampF(drag.y, -t, h - b)
                                            l += dx
                                            rr += dx
                                            t += dy
                                            b += dy
                                        }
                                        2 -> {
                                            l = clampF(l + drag.x, 0f, rr - min)
                                            t = clampF(t + drag.y, 0f, b - min)
                                        }
                                        3 -> {
                                            rr = clampF(rr + drag.x, l + min, w)
                                            t = clampF(t + drag.y, 0f, b - min)
                                        }
                                        4 -> {
                                            l = clampF(l + drag.x, 0f, rr - min)
                                            b = clampF(b + drag.y, t + min, h)
                                        }
                                        5 -> {
                                            rr = clampF(rr + drag.x, l + min, w)
                                            b = clampF(b + drag.y, t + min, h)
                                        }
                                    }
                                    rect = Rect(l, t, rr, b)
                                }
                            }
                        )
                    }
            ) {
                Image(
                    bitmap = image,
                    contentDescription = null,
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier.fillMaxSize()
                )
                Canvas(Modifier.fillMaxSize()) {
                    val r = rect
                    if (r != null) {
                        val shade = Color.Black.copy(alpha = 0.6f)
                        drawRect(shade, Offset.Zero, Size(size.width, r.top))
                        drawRect(shade, Offset(0f, r.bottom), Size(size.width, size.height - r.bottom))
                        drawRect(shade, Offset(0f, r.top), Size(r.left, r.height))
                        drawRect(shade, Offset(r.right, r.top), Size(size.width - r.right, r.height))
                        val accent = Color(0xFF4DD0E1)
                        drawRect(accent, r.topLeft, r.size, style = Stroke(width = 3.dp.toPx()))
                        for (p in listOf(r.topLeft, r.topRight, r.bottomLeft, r.bottomRight)) {
                            drawCircle(accent, 9.dp.toPx(), p)
                        }
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Отмена") }
            Button(
                onClick = {
                    val r = rect
                    if (r != null && boxSize.width > 0 && boxSize.height > 0) {
                        val sx = source.width / boxSize.width.toFloat()
                        val sy = source.height / boxSize.height.toFloat()
                        val x = (r.left * sx).roundToInt().coerceIn(0, source.width - 1)
                        val y = (r.top * sy).roundToInt().coerceIn(0, source.height - 1)
                        val w = ((r.right - r.left) * sx).roundToInt().coerceIn(1, source.width - x)
                        val h = ((r.bottom - r.top) * sy).roundToInt().coerceIn(1, source.height - y)
                        if (w < 16 || h < 16) {
                            toastLong(ctx, "Область слишком мала (минимум 16×16 px)")
                        } else {
                            onDone(Bitmap.createBitmap(source, x, y, w, h))
                        }
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("Сохранить шаблон") }
        }
    }
}
