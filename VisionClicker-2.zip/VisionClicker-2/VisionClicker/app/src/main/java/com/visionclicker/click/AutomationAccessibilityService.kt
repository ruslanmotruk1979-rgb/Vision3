package com.visionclicker.click

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import com.visionclicker.model.AppRuntime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Единственная задача — выполнять одиночные касания через поддерживаемый
 * Accessibility API (dispatchGesture). Содержимое экрана не читается.
 */
class AutomationAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AutomationAccessibilityService? = null
            private set

        /** Включена ли служба в системных настройках (не требует, чтобы процесс уже был связан). */
        fun isEnabled(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val me = ComponentName(context, AutomationAccessibilityService::class.java)
            return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AppRuntime.accessibilityConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // события не нужны
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        AppRuntime.accessibilityConnected.value = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        AppRuntime.accessibilityConnected.value = false
        super.onDestroy()
    }

    /**
     * Выполняет касание и ждёт результата. true — жест выполнен системой.
     * Одновременно выполняется не более одного жеста (ждём завершения предыдущего).
     */
    suspend fun tap(x: Float, y: Float, durationMs: Long): Boolean {
        val ok = withTimeoutOrNull(durationMs + 2000L) {
            withContext(Dispatchers.Main.immediate) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    val path = Path().apply { moveTo(x, y) }
                    val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1L))
                    val gesture = GestureDescription.Builder().addStroke(stroke).build()
                    val callback = object : AccessibilityService.GestureResultCallback() {
                        override fun onCompleted(gestureDescription: GestureDescription?) {
                            if (cont.isActive) cont.resume(true)
                        }

                        override fun onCancelled(gestureDescription: GestureDescription?) {
                            if (cont.isActive) cont.resume(false)
                        }
                    }
                    val accepted = try {
                        dispatchGesture(gesture, callback, null)
                    } catch (e: Exception) {
                        false
                    }
                    if (!accepted && cont.isActive) cont.resume(false)
                }
            }
        }
        return ok ?: false
    }
}
