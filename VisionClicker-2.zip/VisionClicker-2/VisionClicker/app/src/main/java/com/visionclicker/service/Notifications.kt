package com.visionclicker.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.visionclicker.MainActivity
import com.visionclicker.R
import com.visionclicker.model.MonitoringState
import com.visionclicker.overlay.FloatingOverlayService

object Notifications {
    const val CH_MONITOR = "monitoring"
    const val CH_OVERLAY = "overlay"
    const val CH_ALERT = "alerts"

    const val ID_MONITOR = 101
    const val ID_OVERLAY = 102
    const val ID_ALERT = 103

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_MONITOR, "Мониторинг экрана", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Постоянное уведомление, пока идёт наблюдение и возможны автоматические нажатия"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_OVERLAY, "Плавающая панель", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Панель управления поверх других приложений"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Предупреждения", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Остановка мониторинга, ошибки, готовность снимка"
            }
        )
    }

    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        FLAGS
    )

    fun monitoring(ctx: Context, state: MonitoringState, paused: Boolean): Notification {
        val stop = PendingIntent.getService(
            ctx, 1,
            Intent(ctx, MonitoringService::class.java).setAction(MonitoringService.ACTION_STOP), FLAGS
        )
        val pause = PendingIntent.getService(
            ctx, 2,
            Intent(ctx, MonitoringService::class.java).setAction(MonitoringService.ACTION_TOGGLE_PAUSE), FLAGS
        )
        val status = if (paused) "Пауза" else state.title
        return NotificationCompat.Builder(ctx, CH_MONITOR)
            .setSmallIcon(R.drawable.ic_stat_clicker)
            .setContentTitle("Vision Clicker: идёт наблюдение")
            .setContentText("$status · нажатия возможны поверх других приложений")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openApp(ctx))
            .addAction(0, "Остановить", stop)
            .addAction(0, if (paused) "Продолжить" else "Пауза", pause)
            .build()
    }

    fun overlay(ctx: Context): Notification {
        val show = PendingIntent.getService(
            ctx, 3,
            Intent(ctx, FloatingOverlayService::class.java).setAction(FloatingOverlayService.ACTION_SHOW_PANEL), FLAGS
        )
        val close = PendingIntent.getService(
            ctx, 4,
            Intent(ctx, FloatingOverlayService::class.java).setAction(FloatingOverlayService.ACTION_CLOSE), FLAGS
        )
        return NotificationCompat.Builder(ctx, CH_OVERLAY)
            .setSmallIcon(R.drawable.ic_stat_clicker)
            .setContentTitle("Vision Clicker: панель активна")
            .setContentText("Плавающая панель отображается поверх приложений")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(openApp(ctx))
            .addAction(0, "Показать панель", show)
            .addAction(0, "Закрыть", close)
            .build()
    }

    fun alert(ctx: Context, title: String, text: String) {
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_clicker)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx))
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID_ALERT, n)
    }

    fun snapshotReady(ctx: Context) {
        alert(ctx, "Снимок экрана готов", "Нажмите, чтобы выбрать объект и обрезать шаблон")
    }
}
