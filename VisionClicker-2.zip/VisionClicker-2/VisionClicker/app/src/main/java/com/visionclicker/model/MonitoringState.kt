package com.visionclicker.model

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

/** Состояния конечного автомата мониторинга. */
enum class MonitoringState(val title: String, val shortTitle: String) {
    STOPPED("Остановлено", "Стоп"),
    WAITING("Ожидание объекта", "Жду"),
    DETECTED("Объект обнаружен", "Вижу"),
    CLICKING("Выполняются нажатия", "Клик"),
    ERROR("Ошибка", "Ошибка");

    val isRunning: Boolean get() = this == WAITING || this == DETECTED || this == CLICKING
}

/** Команды, которые UI, панель и уведомление отправляют MonitoringService. */
enum class Command { STOP, EMERGENCY_STOP, PAUSE, RESUME, TOGGLE_PAUSE }

/** Найденный объект в координатах экрана. */
data class DetectionInfo(val rect: PxRect, val score: Float)

/**
 * Общее состояние процесса. Сервисы, оверлеи и Compose-UI живут в одном процессе
 * и обмениваются данными через эти потоки.
 */
object AppRuntime {
    val state = MutableStateFlow(MonitoringState.STOPPED)
    val paused = MutableStateFlow(false)
    val errorMessage = MutableStateFlow<String?>(null)

    val objectPresent = MutableStateFlow(false)
    val clicking = MutableStateFlow(false)
    val detection = MutableStateFlow<DetectionInfo?>(null)
    val lastScore = MutableStateFlow(0f)
    val analysisMs = MutableStateFlow(0L)
    val clickCount = MutableStateFlow(0L)
    val matcherNote = MutableStateFlow<String?>(null)

    val accessibilityConnected = MutableStateFlow(false)
    val overlayRunning = MutableStateFlow(false)
    val snapshotInProgress = MutableStateFlow(false)
    val pendingScreenshot = MutableStateFlow(false)
    val markerUnlocked = MutableStateFlow(false)
    val regionEditing = MutableStateFlow(false)
    val panelHidden = MutableStateFlow(false)

    val screen = MutableStateFlow(ScreenSize(1080, 2400, 420))

    @Volatile
    var openCvReady: Boolean = false

    val commands = MutableSharedFlow<Command>(extraBufferCapacity = 16)
}
