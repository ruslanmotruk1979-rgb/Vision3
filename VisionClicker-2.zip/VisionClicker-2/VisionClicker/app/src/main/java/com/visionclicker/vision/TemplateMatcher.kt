package com.visionclicker.vision

import android.graphics.Bitmap
import com.visionclicker.model.MatchMode
import com.visionclicker.model.PxRect
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Поиск шаблона внутри кадра алгоритмом нормированной кросс-корреляции
 * (TM_CCOEFF_NORMED), устойчивым к изменению яркости/контраста.
 *
 *  - EXACT  — цвет, один масштаб;
 *  - SCALED — серое изображение, 5 масштабов (терпимо к оттенку и размеру);
 *  - EDGES  — карта границ (Sobel), 7 масштабов (терпимо к цвету и свечению).
 *
 * Класс не потокобезопасен для внешнего использования буферов, но все публичные
 * методы синхронизированы, поэтому шаблон можно менять из другого потока.
 */
class TemplateMatcher {

    data class Params(
        val mode: MatchMode,
        val threshold: Float,
        val minSizePx: Int,
        val analysisScale: Float
    )

    data class Result(
        val found: Boolean,
        val score: Float,
        /** Рамка найденного объекта в координатах ОБЛАСТИ (не экрана). */
        val rect: PxRect?,
        val note: String? = null
    )

    companion object {
        /** Второй пик должен быть заметно ниже лучшего, иначе совпадение неоднозначное (стены, плитка). */
        const val UNIQUE_RATIO = 0.92f
    }

    private enum class Kind { COLOR, GRAY, EDGES }

    private class EdgeScratch {
        val blur = Mat()
        val gx = Mat()
        val gy = Mat()
        val ax = Mat()
        val ay = Mat()
        fun release() {
            blur.release(); gx.release(); gy.release(); ax.release(); ay.release()
        }
    }

    private val lock = Any()

    private var template: Mat? = null // RGBA, полное разрешение
    private var tplW = 0
    private var tplH = 0
    private var flat = false
    private val cache = HashMap<String, Mat>()

    // переиспользуемые буферы
    private val base = Mat()
    private val scaled = Mat()
    private val edgeOut = Mat()
    private val result = Mat()
    private val uniqMat = Mat()
    private val regionEdge = EdgeScratch()
    private var lastScale = 1.0

    fun setTemplate(bmp: Bitmap?) {
        synchronized(lock) {
            clearCache()
            template?.release()
            template = null
            flat = false
            tplW = 0
            tplH = 0
            if (bmp == null) return

            val src: Bitmap = if (bmp.config == Bitmap.Config.ARGB_8888) bmp
            else (bmp.copy(Bitmap.Config.ARGB_8888, false) ?: return)
            val m = Mat()
            Utils.bitmapToMat(src, m)
            template = m
            tplW = m.cols()
            tplH = m.rows()

            // однотонный шаблон нельзя надёжно искать
            val gray = Mat()
            Imgproc.cvtColor(m, gray, Imgproc.COLOR_RGBA2GRAY)
            val mean = MatOfDouble()
            val std = MatOfDouble()
            Core.meanStdDev(gray, mean, std)
            val s = std.toArray()
            flat = s.isEmpty() || s[0] < 3.0
            gray.release()
            mean.release()
            std.release()
            lastScale = 1.0
        }
    }

    fun match(regionRgba: Mat, p: Params): Result = synchronized(lock) { matchLocked(regionRgba, p) }

    fun release() {
        synchronized(lock) {
            clearCache()
            template?.release()
            template = null
            base.release()
            scaled.release()
            edgeOut.release()
            result.release()
            uniqMat.release()
            regionEdge.release()
        }
    }

    // ------------------------------------------------------------------

    private fun matchLocked(regionRgba: Mat, p: Params): Result {
        val tpl = template ?: return Result(false, 0f, null, "Шаблон не выбран")
        if (flat) return Result(false, 0f, null, "Шаблон однотонный — выберите объект с деталями")
        if (regionRgba.empty()) return Result(false, 0f, null, "Пустой кадр")

        val kind = when (p.mode) {
            MatchMode.EXACT -> Kind.COLOR
            MatchMode.SCALED -> Kind.GRAY
            MatchMode.EDGES -> Kind.EDGES
        }
        val scales: List<Double> = when (p.mode) {
            MatchMode.EXACT -> listOf(1.0)
            MatchMode.SCALED -> listOf(1.0, 0.8, 1.25, 0.65, 1.5, 0.5, 2.0)
            MatchMode.EDGES -> listOf(1.0, 0.8, 1.25, 0.65, 1.5, 0.5, 2.0)
        }
        val k = p.analysisScale.toDouble().coerceIn(0.25, 1.0)
        val image = prepareRegion(regionRgba, kind, k)

        // сначала пробуем масштаб, на котором объект нашли в прошлый раз
        val order = scales.sortedBy { if (it == lastScale) 0 else 1 }

        var best = 0f
        var bestRect: PxRect? = null
        var bestScale = lastScale
        var tried = 0

        for (s in order) {
            val eff = k * s
            val tw = (tplW * eff).roundToInt()
            val th = (tplH * eff).roundToInt()
            if (minOf(tplW * s, tplH * s) < p.minSizePx) continue
            if (tw < 8 || th < 8) continue
            if (tw > image.cols() || th > image.rows()) continue

            val t = preparedTemplate(tpl, kind, tw, th)
            Imgproc.matchTemplate(image, t, result, Imgproc.TM_CCOEFF_NORMED)
            Core.patchNaNs(result, 0.0)
            val mm = Core.minMaxLoc(result)
            tried++

            var score = mm.maxVal.toFloat()
            if (score >= p.threshold && !isUnique(result, mm.maxLoc, tw, th, score)) {
                score *= 0.5f // несколько почти одинаковых пиков: скорее фон (стена), а не объект
            }
            if (score > best || bestRect == null) {
                best = score
                bestScale = s
                bestRect = PxRect(
                    (mm.maxLoc.x / k).roundToInt(),
                    (mm.maxLoc.y / k).roundToInt(),
                    ((mm.maxLoc.x + tw) / k).roundToInt(),
                    ((mm.maxLoc.y + th) / k).roundToInt()
                )
            }
            if (score >= p.threshold) break // достаточно уверенное совпадение — дальше не ищем
        }

        if (tried == 0) {
            return Result(false, 0f, null, "Шаблон не помещается в область или меньше минимального размера")
        }
        val found = best >= p.threshold
        if (found) lastScale = bestScale
        return Result(found, best, if (found) bestRect else null)
    }

    /** true, если вне окрестности лучшего пика нет почти такого же совпадения. */
    private fun isUnique(res: Mat, peak: Point, tw: Int, th: Int, best: Float): Boolean {
        res.copyTo(uniqMat)
        val px = peak.x.toInt()
        val py = peak.y.toInt()
        val x0 = max(0, px - tw / 2)
        val y0 = max(0, py - th / 2)
        val x1 = min(uniqMat.cols(), px + tw / 2 + 1)
        val y1 = min(uniqMat.rows(), py + th / 2 + 1)
        if (x1 > x0 && y1 > y0) {
            uniqMat.submat(Rect(x0, y0, x1 - x0, y1 - y0)).setTo(Scalar(-1.0))
        }
        val second = Core.minMaxLoc(uniqMat).maxVal.toFloat()
        return second < best * UNIQUE_RATIO
    }

    private fun prepareRegion(rgba: Mat, kind: Kind, k: Double): Mat {
        Imgproc.cvtColor(
            rgba, base,
            if (kind == Kind.COLOR) Imgproc.COLOR_RGBA2RGB else Imgproc.COLOR_RGBA2GRAY
        )
        var cur: Mat = base
        if (k < 0.999) {
            val nw = max(1, (cur.cols() * k).roundToInt())
            val nh = max(1, (cur.rows() * k).roundToInt())
            Imgproc.resize(cur, scaled, Size(nw.toDouble(), nh.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
            cur = scaled
        }
        if (kind == Kind.EDGES) {
            edges(cur, edgeOut, regionEdge)
            cur = edgeOut
        }
        return cur
    }

    private fun preparedTemplate(tpl: Mat, kind: Kind, tw: Int, th: Int): Mat {
        val key = "${kind.name}:$tw:$th"
        cache[key]?.let { return it }
        if (cache.size > 24) clearCache()

        val conv = Mat()
        Imgproc.cvtColor(
            tpl, conv,
            if (kind == Kind.COLOR) Imgproc.COLOR_RGBA2RGB else Imgproc.COLOR_RGBA2GRAY
        )
        val resized = Mat()
        val interp = if (tw < tpl.cols()) Imgproc.INTER_AREA else Imgproc.INTER_LINEAR
        Imgproc.resize(conv, resized, Size(tw.toDouble(), th.toDouble()), 0.0, 0.0, interp)
        conv.release()

        val out: Mat
        if (kind == Kind.EDGES) {
            val sc = EdgeScratch()
            out = Mat()
            edges(resized, out, sc)
            sc.release()
            resized.release()
        } else {
            out = resized
        }
        cache[key] = out
        return out
    }

    private fun edges(src: Mat, dst: Mat, s: EdgeScratch) {
        Imgproc.GaussianBlur(src, s.blur, Size(3.0, 3.0), 0.0)
        Imgproc.Sobel(s.blur, s.gx, CvType.CV_16S, 1, 0)
        Imgproc.Sobel(s.blur, s.gy, CvType.CV_16S, 0, 1)
        Core.convertScaleAbs(s.gx, s.ax)
        Core.convertScaleAbs(s.gy, s.ay)
        Core.addWeighted(s.ax, 0.5, s.ay, 0.5, 0.0, dst)
    }

    private fun clearCache() {
        for (m in cache.values) m.release()
        cache.clear()
    }
}
