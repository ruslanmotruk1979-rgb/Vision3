package com.visionclicker.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.visionclicker.model.AppSettings
import com.visionclicker.model.NormPoint
import com.visionclicker.model.NormRect
import com.visionclicker.model.TemplateItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Локальное хранилище настроек и шаблонов. Ничего не отправляется в сеть.
 * Шаблоны: файлы templates/<id>.png + список (название, вкл/выкл) в SharedPreferences.
 */
class SettingsRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("vision_clicker_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()
    val current: AppSettings get() = _settings.value

    val screenshotFile: File get() = File(context.filesDir, "screenshot.png")

    private val templatesDir: File = File(context.filesDir, "templates").also { it.mkdirs() }

    private val _templateVersion = MutableStateFlow(0)
    val templateVersion: StateFlow<Int> = _templateVersion.asStateFlow()

    private val _templates = MutableStateFlow(migrateAndLoad())
    val templates: StateFlow<List<TemplateItem>> = _templates.asStateFlow()

    fun update(transform: (AppSettings) -> AppSettings) {
        var saved = _settings.value
        _settings.update { old -> transform(old).also { saved = it } }
        save(saved)
    }

    fun resetSettings() {
        update { AppSettings(warningAccepted = it.warningAccepted) }
    }

    // ---------------- шаблоны ----------------

    private fun fileFor(id: String): File = File(templatesDir, "$id.png")

    /** Включённые шаблоны, у которых есть файл изображения. */
    fun enabledTemplates(): List<TemplateItem> =
        _templates.value.filter { it.enabled && fileFor(it.id).exists() }

    fun hasEnabledTemplate(): Boolean = enabledTemplates().isNotEmpty()

    fun loadTemplate(id: String): Bitmap? {
        val f = fileFor(id)
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    }

    /** Добавляет шаблон. Возвращает его id. */
    fun addTemplate(bmp: Bitmap, name: String? = null): String {
        val id = System.currentTimeMillis().toString()
        FileOutputStream(fileFor(id)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val current = _templates.value
        val item = TemplateItem(id, name ?: "Объект ${current.size + 1}", true)
        commit(current + item)
        return id
    }

    fun deleteTemplate(id: String) {
        fileFor(id).delete()
        commit(_templates.value.filter { it.id != id })
    }

    fun renameTemplate(id: String, name: String) {
        commit(_templates.value.map { if (it.id == id) it.copy(name = name) else it })
    }

    fun setTemplateEnabled(id: String, enabled: Boolean) {
        commit(_templates.value.map { if (it.id == id) it.copy(enabled = enabled) else it })
    }

    private fun commit(list: List<TemplateItem>) {
        _templates.value = list
        prefs.edit().putString(KEY_TEMPLATES, toJson(list)).apply()
        _templateVersion.update { it + 1 }
    }

    private fun migrateAndLoad(): List<TemplateItem> {
        val stored = prefs.getString(KEY_TEMPLATES, null)
        if (stored != null) return parse(stored)
        // миграция со старой версии (один шаблон template.png)
        val legacy = File(context.filesDir, "template.png")
        if (legacy.exists()) {
            legacy.renameTo(fileFor(LEGACY_ID))
            val list = listOf(TemplateItem(LEGACY_ID, "Объект 1", true))
            prefs.edit().putString(KEY_TEMPLATES, toJson(list)).apply()
            return list
        }
        return emptyList()
    }

    private fun toJson(list: List<TemplateItem>): String {
        val arr = JSONArray()
        for (t in list) {
            arr.put(JSONObject().put("id", t.id).put("name", t.name).put("enabled", t.enabled))
        }
        return arr.toString()
    }

    private fun parse(s: String): List<TemplateItem> = try {
        val arr = JSONArray(s)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            TemplateItem(o.getString("id"), o.getString("name"), o.optBoolean("enabled", true))
        }.filter { fileFor(it.id).exists() }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveScreenshot(bmp: Bitmap) {
        FileOutputStream(screenshotFile).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun loadScreenshot(): Bitmap? =
        if (screenshotFile.exists()) BitmapFactory.decodeFile(screenshotFile.absolutePath) else null

    fun deleteScreenshot() {
        screenshotFile.delete()
    }

    // ---------------- настройки ----------------

    private inline fun <reified E : Enum<E>> enumOf(name: String?, def: E): E =
        enumValues<E>().firstOrNull { it.name == name } ?: def

    private fun rect(key: String, def: NormRect) = NormRect(
        prefs.getFloat("${key}_l", def.left),
        prefs.getFloat("${key}_t", def.top),
        prefs.getFloat("${key}_r", def.right),
        prefs.getFloat("${key}_b", def.bottom)
    )

    private fun point(key: String, def: NormPoint) = NormPoint(
        prefs.getFloat("${key}_x", def.x),
        prefs.getFloat("${key}_y", def.y)
    )

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            threshold = prefs.getFloat("threshold", d.threshold),
            matchMode = enumOf(prefs.getString("matchMode", null), d.matchMode),
            minObjectSizePx = prefs.getInt("minObjectSizePx", d.minObjectSizePx),
            showDetectionBox = prefs.getBoolean("showDetectionBox", d.showDetectionBox),
            confirmFrames = prefs.getInt("confirmFrames", d.confirmFrames),
            lossFrames = prefs.getInt("lossFrames", d.lossFrames),

            fullScreen = prefs.getBoolean("fullScreen", d.fullScreen),
            regionPortrait = rect("regionP", d.regionPortrait),
            regionLandscape = rect("regionL", d.regionLandscape),
            frameVisible = prefs.getBoolean("frameVisible", d.frameVisible),
            frameColor = prefs.getInt("frameColor", d.frameColor),
            frameAlpha = prefs.getFloat("frameAlpha", d.frameAlpha),

            clickerEnabled = prefs.getBoolean("clickerEnabled", d.clickerEnabled),
            clickMode = enumOf(prefs.getString("clickMode", null), d.clickMode),
            clickIntervalMs = prefs.getInt("clickIntervalMs", d.clickIntervalMs),
            tapDurationMs = prefs.getInt("tapDurationMs", d.tapDurationMs),
            maxClicksPerAppearance = prefs.getInt("maxClicksPerAppearance", d.maxClicksPerAppearance),
            clickerPortrait = point("clickP", d.clickerPortrait),
            clickerLandscape = point("clickL", d.clickerLandscape),
            markerVisible = prefs.getBoolean("markerVisible", d.markerVisible),

            checkIntervalMs = prefs.getInt("checkIntervalMs", d.checkIntervalMs),
            performance = enumOf(prefs.getString("performance", null), d.performance),

            autoShowPanel = prefs.getBoolean("autoShowPanel", d.autoShowPanel),
            panelCollapsedOnStart = prefs.getBoolean("panelCollapsedOnStart", d.panelCollapsedOnStart),
            panelOpacity = prefs.getFloat("panelOpacity", d.panelOpacity),

            warningAccepted = prefs.getBoolean("warningAccepted", d.warningAccepted)
        )
    }

    private fun save(s: AppSettings) {
        val e = prefs.edit()
        e.putFloat("threshold", s.threshold)
        e.putString("matchMode", s.matchMode.name)
        e.putInt("minObjectSizePx", s.minObjectSizePx)
        e.putBoolean("showDetectionBox", s.showDetectionBox)
        e.putInt("confirmFrames", s.confirmFrames)
        e.putInt("lossFrames", s.lossFrames)

        e.putBoolean("fullScreen", s.fullScreen)
        putRect(e, "regionP", s.regionPortrait)
        putRect(e, "regionL", s.regionLandscape)
        e.putBoolean("frameVisible", s.frameVisible)
        e.putInt("frameColor", s.frameColor)
        e.putFloat("frameAlpha", s.frameAlpha)

        e.putBoolean("clickerEnabled", s.clickerEnabled)
        e.putString("clickMode", s.clickMode.name)
        e.putInt("clickIntervalMs", s.clickIntervalMs)
        e.putInt("tapDurationMs", s.tapDurationMs)
        e.putInt("maxClicksPerAppearance", s.maxClicksPerAppearance)
        putPoint(e, "clickP", s.clickerPortrait)
        putPoint(e, "clickL", s.clickerLandscape)
        e.putBoolean("markerVisible", s.markerVisible)

        e.putInt("checkIntervalMs", s.checkIntervalMs)
        e.putString("performance", s.performance.name)

        e.putBoolean("autoShowPanel", s.autoShowPanel)
        e.putBoolean("panelCollapsedOnStart", s.panelCollapsedOnStart)
        e.putFloat("panelOpacity", s.panelOpacity)

        e.putBoolean("warningAccepted", s.warningAccepted)
        e.apply()
    }

    private fun putRect(e: android.content.SharedPreferences.Editor, key: String, r: NormRect) {
        e.putFloat("${key}_l", r.left)
        e.putFloat("${key}_t", r.top)
        e.putFloat("${key}_r", r.right)
        e.putFloat("${key}_b", r.bottom)
    }

    private fun putPoint(e: android.content.SharedPreferences.Editor, key: String, p: NormPoint) {
        e.putFloat("${key}_x", p.x)
        e.putFloat("${key}_y", p.y)
    }

    companion object {
        private const val KEY_TEMPLATES = "templates_json"
        private const val LEGACY_ID = "legacy"
    }
}
