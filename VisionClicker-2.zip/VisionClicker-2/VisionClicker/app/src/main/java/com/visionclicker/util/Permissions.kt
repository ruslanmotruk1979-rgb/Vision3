package com.visionclicker.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.visionclicker.click.AutomationAccessibilityService

data class PermissionState(
    val overlay: Boolean,
    val accessibility: Boolean,
    val notifications: Boolean,
    val batteryUnrestricted: Boolean
) {
    /** Без этих двух разрешений мониторинг с кликами невозможен. */
    val required: Boolean get() = overlay && accessibility
}

object Permissions {

    fun read(ctx: Context): PermissionState {
        val notif = if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else true
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return PermissionState(
            overlay = Settings.canDrawOverlays(ctx),
            accessibility = AutomationAccessibilityService.isEnabled(ctx),
            notifications = notif,
            batteryUnrestricted = pm.isIgnoringBatteryOptimizations(ctx.packageName)
        )
    }

    fun openOverlaySettings(ctx: Context) =
        launch(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))

    fun openAccessibilitySettings(ctx: Context) =
        launch(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    fun openAppDetails(ctx: Context) =
        launch(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))

    fun openNotificationSettings(ctx: Context) =
        launch(ctx, Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))

    fun openBatterySettings(ctx: Context) =
        launch(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))

    private fun launch(ctx: Context, intent: Intent) {
        try {
            ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Не удалось открыть настройки: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
