package com.visionclicker

import android.app.Application
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.view.Display
import com.visionclicker.data.SettingsRepository
import com.visionclicker.model.AppRuntime
import com.visionclicker.region.RegionManager
import com.visionclicker.service.Notifications
import com.visionclicker.util.ScreenMetrics
import org.opencv.android.OpenCVLoader

class AppContainer(app: Application) {
    val settings = SettingsRepository(app)
    val regions = RegionManager(settings)
}

class VisionClickerApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        AppRuntime.screen.value = ScreenMetrics.real(this)
        container = AppContainer(this)
        Notifications.createChannels(this)

        AppRuntime.openCvReady = try {
            OpenCVLoader.initLocal()
        } catch (t: Throwable) {
            false
        }

        // Поворот экрана / смена разрешения: обновляем размеры и область наблюдения.
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        dm.registerDisplayListener(object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) {
                if (displayId != Display.DEFAULT_DISPLAY) return
                val s = ScreenMetrics.real(this@VisionClickerApp)
                if (s != AppRuntime.screen.value) {
                    AppRuntime.screen.value = s
                    container.regions.onScreenChanged()
                }
            }
        }, Handler(Looper.getMainLooper()))
    }
}

val Context.container: AppContainer
    get() = (applicationContext as VisionClickerApp).container
